import os
import signal
import subprocess
import psutil

class IncidentResponder:
    def __init__(self, config: dict):
        self.config = config

    def terminate_process_tree(self, pid: int):
        """Recursively terminates a process and all its children."""
        try:
            parent = psutil.Process(pid)
            children = parent.children(recursive=True)
            for child in children:
                child.send_signal(signal.SIGKILL)
            parent.send_signal(signal.SIGKILL)
            print(f"[ACTION] Terminated suspicious process PID: {pid}")
        except psutil.NoSuchProcess:
            pass
        except Exception as e:
            print(f"[ERROR] Failed to terminate PID {pid}: {e}")

    def isolate_network(self):
        """Drops all network traffic except SSH management access."""
        if not self.config["response"].get("enable_network_isolation", False):
            print("[INFO] Network isolation disabled in config. Skipping iptables cutoff.")
            return

        admin_port = self.config["response"].get("admin_port", 22)
        commands = [
            "iptables -F",
            "iptables -A INPUT -i lo -j ACCEPT",
            "iptables -A OUTPUT -o lo -j ACCEPT",
            f"iptables -A INPUT -p tcp --dport {admin_port} -j ACCEPT",
            f"iptables -A OUTPUT -p tcp --sport {admin_port} -j ACCEPT",
            "iptables -P INPUT DROP",
            "iptables -P FORWARD DROP",
            "iptables -P OUTPUT DROP"
        ]
        
        print("[ACTION] Applying network isolation via iptables...")
        for cmd in commands:
            subprocess.run(cmd, shell=True, check=False)