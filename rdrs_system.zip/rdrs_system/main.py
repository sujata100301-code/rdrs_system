import os
import time
import yaml
from watchdog.observers import Observer
from detector import RansomwareMonitorHandler
import responder as responder_

def load_config(path="config.yaml"):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def deploy_canaries(watch_dir: str, canary_name: str):
    os.makedirs(watch_dir, exist_ok=True)
    canary_path = os.path.join(watch_dir, canary_name)
    if not os.path.exists(canary_path):
        with open(canary_path, "w") as f:
            f.write("CANARY_TRAP_DO_NOT_MODIFY")

def main():
    config = load_config()
    watch_dir = config["monitor"]["watch_dir"]
    canary_name = config["monitor"]["canary_filename"]
    
    deploy_canaries(watch_dir, canary_name)
    responder = responder_.IncidentResponder(config)

    def alert_handler(reason: str, high_priority: bool):
        print(f"\n[ALERT] Threat Detected! Reason: {reason}")
        if high_priority:
            responder.isolate_network()

    event_handler = RansomwareMonitorHandler(config, alert_handler)
    observer = Observer()
    observer.schedule(event_handler, path=watch_dir, recursive=True)
    
    print(f"[*] RDRS Daemon running. Monitoring directory: {watch_dir}")
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Stopping RDRS Daemon...")
        observer.stop()
    observer.join()

if __name__ == "__main__":
    main()