import json
import logging
import os
from datetime import datetime

def setup_forensic_logger(log_path: str = "./rdrs_events.json"):
    """Initializes the logger and creates the log file if it doesn't exist."""
    logger = logging.getLogger("RDRS_Forensics")
    logger.setLevel(logging.INFO)
    
    # Avoid duplicate handlers if re-initialized
    if not logger.handlers:
        handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
    return logger

def log_incident(logger, threat_type: str, score: int, filepath: str, pid: int, action_taken: str):
    """Writes a single-line JSON log entry for every security event."""
    event = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "threat_type": threat_type,
        "threat_score": score,
        "target_file": filepath,
        "associated_pid": pid if pid else "N/A",
        "action_taken": action_taken
    }
    logger.info(json.dumps(event))
    print(f"[AUDIT LOGGED] {json.dumps(event)}")