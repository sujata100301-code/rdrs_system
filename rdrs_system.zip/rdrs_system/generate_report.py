import json
import os

LOG_FILE = "rdrs_events.json"
HTML_OUTPUT = "forensic_report.html"

def load_events(log_path: str):
    events = []
    if not os.path.exists(log_path):
        return events
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return events

def generate_html_report():
    events = load_events(LOG_FILE)
    
    total_events = len(events)
    high_threats = sum(1 for e in events if e.get("threat_score", 0) >= 80)
    
    rows = ""
    for ev in events:
        score = ev.get("threat_score", 0)
        badge_class = "danger" if score >= 80 else ("warning" if score >= 50 else "info")
        
        rows += f"""
        <tr>
            <td>{ev.get("timestamp", "N/A")}</td>
            <td><span class="badge {badge_class}">{score}</span></td>
            <td>{ev.get("threat_type", "N/A")}</td>
            <td><code>{ev.get("target_file", "N/A")}</code></td>
            <td>{ev.get("associated_pid", "N/A")}</td>
            <td>{ev.get("action_taken", "N/A")}</td>
        </tr>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RDRS Incident & Forensic Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: #f4f6f8; margin: 0; padding: 24px; color: #333; }}
        .container {{ max-width: 1100px; margin: auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); padding: 32px; }}
        h1 {{ margin-top: 0; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }}
        .metrics-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }}
        .metric-card {{ background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; text-align: center; }}
        .metric-value {{ font-size: 28px; font-weight: bold; color: #0f172a; margin-top: 8px; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 14px; }}
        th, td {{ padding: 12px 14px; text-align: left; border-bottom: 1px solid #e2e8f0; }}
        th {{ background-color: #f1f5f9; color: #475569; font-weight: 600; }}
        tr:hover {{ background-color: #f8fafc; }}
        code {{ background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: monospace; }}
        .badge {{ padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 12px; color: #fff; }}
        .danger {{ background-color: #ef4444; }}
        .warning {{ background-color: #f59e0b; }}
        .info {{ background-color: #3b82f6; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>RDRS Security Forensic Report</h1>
        <div class="metrics-grid">
            <div class="metric-card">
                <div>Total Detections</div>
                <div class="metric-value">{total_events}</div>
            </div>
            <div class="metric-card">
                <div>Critical Alerts (&ge;80)</div>
                <div class="metric-value" style="color: #ef4444;">{high_threats}</div>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Timestamp (UTC)</th>
                    <th>Score</th>
                    <th>Threat Signature</th>
                    <th>Target Resource</th>
                    <th>PID</th>
                    <th>Action Taken</th>
                </tr>
            </thead>
            <tbody>
                {rows if rows else '<tr><td colspan="6" style="text-align:center;">No forensic events recorded.</td></tr>'}
            </tbody>
        </table>
    </div>
</body>
</html>"""

    with open(HTML_OUTPUT, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"[+] Forensic report successfully written to {HTML_OUTPUT}")

if __name__ == "__main__":
    generate_html_report()