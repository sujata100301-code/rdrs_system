import os
import secrets

SANDBOX_DIR = "./sandbox"

def test_entropy_attack():
    os.makedirs(SANDBOX_DIR, exist_ok=True)
    for i in range(10):
        target = os.path.join(SANDBOX_DIR, f"doc_{i}.enc")
        with open(target, "wb") as f:
            f.write(secrets.token_bytes(4096))
        print(f"[TEST] Wrote encrypted sample: {target}")

if __name__ == "__main__":
    test_entropy_attack()