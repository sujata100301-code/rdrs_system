import os
import math
import time
from collections import Counter
from watchdog.events import FileSystemEventHandler
from utils import get_pid_accessing_file

def calculate_shannon_entropy(filepath: str) -> float:
    try:
        with open(filepath, "rb") as f:
            data = f.read(65536)
            if not data:
                return 0.0
            length = len(data)
            counts = Counter(data)
            return -sum((count / length) * math.log2(count / length) for count in counts.values())
    except Exception:
        return 0.0

class MultiVectorRansomwareDetector(FileSystemEventHandler):
    def __init__(self, config: dict, alert_callback):
        super().__init__()
        self.config = config
        self.alert_callback = alert_callback
        self.event_timestamps = []
        self.canary_name = config["monitor"]["canary_filename"]
        self.entropy_threshold = config["monitor"]["entropy_threshold"]
        self.rate_count = config["monitor"]["rate_limit_count"]
        self.rate_window = config["monitor"]["rate_limit_seconds"]
        self.known_exts = tuple(config["monitor"]["known_bad_extensions"])
        self.scoring = config["scoring"]

    def _evaluate_event(self, event_path: str):
        now = time.time()
        threat_score = 0
        reasons = []

        # 1. Canary Breach Check
        if self.canary_name in event_path:
            threat_score += self.scoring["canary_weight"]
            reasons.append("Canary file tampered")

        # 2. Known Ransomware Extension Check
        if event_path.endswith(self.known_exts):
            threat_score += self.scoring["bad_extension_weight"]
            reasons.append("Suspicious extension detected")

        # 3. Shannon Entropy Check
        entropy = calculate_shannon_entropy(event_path)
        if entropy >= self.entropy_threshold:
            threat_score += self.scoring["entropy_weight"]
            reasons.append(f"High entropy payload ({entropy:.2f})")

        # 4. Burst Rate Tracking
        self.event_timestamps.append(now)
        self.event_timestamps = [t for t in self.event_timestamps if now - t <= self.rate_window]
        if len(self.event_timestamps) >= self.rate_count:
            threat_score += self.scoring["burst_rate_weight"]
            reasons.append("High write/modify frequency")
            self.event_timestamps.clear()

        # Action Threshold Evaluation
        if threat_score >= self.scoring["alert_threshold"]:
            pid = get_pid_accessing_file(event_path)
            self.alert_callback(
                filepath=event_path,
                reasons=", ".join(reasons),
                score=threat_score,
                pid=pid
            )

    def on_modified(self, event):
        if not event.is_directory:
            self._evaluate_event(event.src_path)

    def on_created(self, event):
        if not event.is_directory:
            self._evaluate_event(event.src_path)